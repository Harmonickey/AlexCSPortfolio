using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace LbKStudiosGame
{
    class ControlScreen : MenuScreen
    {

        public ControlScreen()
            : base ("Controls")
        {

        }
    }
}
