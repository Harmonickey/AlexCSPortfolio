﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("JAMGameFinal")]
[assembly: AssemblyProduct("JAMGameFinal")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("J|A|M")]
[assembly: AssemblyCopyright("Copyright © J|A|M 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components. Xbox 360 assemblies do not support COM.
[assembly: ComVisible(false)]

// If this assembly is the startup assembly, the following Guid is used to
// uniquely identify the title storage container when deploying this assembly
// to the Xbox 360 console.
[assembly: Guid("f086f5db-b2a3-4d71-b776-d5e661451650")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("10.5.7.0")]