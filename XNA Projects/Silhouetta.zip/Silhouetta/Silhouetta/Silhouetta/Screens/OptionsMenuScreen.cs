using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Silhouetta
{
    class OptionsMenuScreen : MenuScreen
    {

        public OptionsMenuScreen()
            : base("Options")
        {

        }
    }
}
